const category=["문화생활","식비","교통비","관리비","공과금","경조사","카드대금","의류","생필품","교육비","의료비","미용비","통신비"]

const card=[{name:"우리체크카드",bank:"woori"},{name:"국민체크카드",bank:"kb"},{name:"농협체크카드",bank:"nh"},{name:"카카오체크카드",bank:"kakao"}];
const bank=[{name:"우리체크카드",bank:"woori",money:123000},{name:"국민체크카드",bank:"kb",money:120000},{name:"농협체크카드",bank:"nh",money:780000},{name:"카카오체크카드",bank:"kakao",money:20030}];
function two_digit(num){
    return num<10 ? "0"+num : num;
}

window.onload=function(){
    var today = new Date();
    var year = today.getFullYear();
    var month = two_digit(today.getMonth()+1);
    var date = two_digit(today.getDate());
    var hour = two_digit(today.getHours());
    var minute = two_digit(today.getMinutes());
    
    // month = month<10 ? "0"+month : month;
    // date = date<10 ? "0"+date : date;
    // hour = hour<10 ? "0"+hour : hour;
    // minute = minute<10 ? "0"+minute : minute;

    var wdate = document.querySelector("#wdate");
    wdate.value=year+"-"+month+"-"+date+" "+hour+":"+minute;

    var cate = document.querySelector("#wcategory");

    for(var i=0; i<category.length; i++){
        var opt =document.createElement("option");
        opt.setAttribute("value",category[i]);
        opt.innerText=category[i];
        cate.appendChild(opt);
    }

    var mycard=document.querySelector("#mycard");
    for(var i in card){
        var opt =document.createElement("option");
        opt.setAttribute("value",card[i].bank);
        opt.innerText=card[i].name;
        mycard.appendChild(opt);
    }

    var mybank=document.querySelector("#mybank");
    for(var i in bank){
        var opt =document.createElement("option");
        opt.setAttribute("value",bank[i].bank);
        opt.innerText=bank[i].name;
        mybank.appendChild(opt);
    }

    var payment = document.getElementsByName("payment");
    payment[0].addEventListener("click",function(){
        document.querySelector("#mycard").classList.add("hide");
    });
    payment[1].addEventListener("click",function(){
        document.querySelector("#mycard").classList.remove("hide");
    })

    var income_bt =document.querySelector("#income_bt");
    income_bt.addEventListener("click",function(){
        var ex = document.getElementsByClassName("expense")[0];
        var inc = document.getElementsByClassName("income")[0];
        ex.classList.add("hide");
        inc.classList.remove("hide");
    });

    var expense_bt =document.querySelector("#expense_bt");
    expense_bt.addEventListener("click",function(){
        var ex = document.getElementsByClassName("expense")[0];
        var inc = document.getElementsByClassName("income")[0];
        ex.classList.remove("hide");
        inc.classList.add("hide");
    });

    var income_type = document.getElementsByName("income_type");
    income_type[0].addEventListener("click",function(){
        document.querySelector("#mybank").classList.remove("hide");
    });
    income_type[1].addEventListener("click",function(){
        document.querySelector("#mybank").classList.add("hide");
    })
}

